/**
 * Mermaid Animations Module
 * 
 * This module provides interactive animations for Mermaid diagrams
 * in Docusaurus, enhancing the user experience with dynamic visualizations.
 */

import ExecutionEnvironment from '@docusaurus/ExecutionEnvironment';

// Only execute in browser environment
if (ExecutionEnvironment.canUseDOM) {
  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeAnimations);
  } else {
    initializeAnimations();
  }
  
  // Re-initialize on route change
  document.addEventListener('docusaurus.routeDidUpdate', () => {
    // Wait for DOM to update and Mermaid to render
    setTimeout(initializeAnimations, 500);
  });
}

function initializeAnimations() {
  console.log('Initializing Mermaid animations...');
  
  // Wait for Mermaid diagrams to be rendered
  const checkInterval = setInterval(() => {
    const diagrams = document.querySelectorAll('.mermaid[data-processed="true"]');
    if (diagrams.length > 0) {
      clearInterval(checkInterval);
      console.log(`Found ${diagrams.length} rendered Mermaid diagrams. Applying animations...`);
      
      // Apply animations to each diagram
      diagrams.forEach(diagram => {
        enhanceDiagram(diagram);
      });
    }
  }, 300);
  
  // Set a timeout to stop checking after 10 seconds
  setTimeout(() => {
    clearInterval(checkInterval);
  }, 10000);
}

function enhanceDiagram(diagram) {
  // Skip if already enhanced
  if (diagram.classList.contains('mermaid-enhanced')) {
    return;
  }
  
  // Mark as enhanced
  diagram.classList.add('mermaid-enhanced');
  
  // Get parent container
  const container = diagram.closest('.docusaurus-mermaid-container') || diagram.parentNode;
  
  // Add animation container class
  container.classList.add('mermaid-animation-container');
  
  // Get diagram type
  const diagramType = getDiagramType(diagram);
  
  // Apply type-specific enhancements
  switch (diagramType) {
    case 'flowchart':
      enhanceFlowchart(diagram, container);
      break;
    case 'sequenceDiagram':
      enhanceSequenceDiagram(diagram, container);
      break;
    case 'classDiagram':
      enhanceClassDiagram(diagram, container);
      break;
    default:
      enhanceGenericDiagram(diagram, container);
      break;
  }
  
  // Add zoom controls
  addZoomControls(diagram, container);
  
  // Add node interactivity
  addNodeInteractivity(diagram, container);
  
  // Add progressive reveal
  addProgressiveReveal(diagram, container);
  
  // Check for animation attributes
  const animationContainer = diagram.closest('[data-animation]');
  if (animationContainer) {
    const animationType = animationContainer.getAttribute('data-animation');
    const animationSpeed = parseFloat(animationContainer.getAttribute('data-animation-speed') || '1');
    
    // Initialize specific animation
    initializeSpecificAnimation(diagram, container, animationType, animationSpeed);
  }
}

function getDiagramType(diagram) {
  // Check SVG content to determine diagram type
  const svg = diagram.querySelector('svg');
  if (!svg) return 'unknown';
  
  if (svg.querySelector('.flowchart')) return 'flowchart';
  if (svg.querySelector('.sequenceDiagram')) return 'sequenceDiagram';
  if (svg.querySelector('.classDiagram')) return 'classDiagram';
  if (svg.querySelector('.stateDiagram')) return 'stateDiagram';
  if (svg.querySelector('.gantt')) return 'ganttChart';
  if (svg.querySelector('.journey')) return 'userJourney';
  if (svg.querySelector('.er')) return 'erDiagram';
  
  // Default to generic
  return 'generic';
}

function enhanceFlowchart(diagram, container) {
  // Get all nodes and edges
  const nodes = diagram.querySelectorAll('.node');
  const edges = diagram.querySelectorAll('.edgePath');
  
  // Add flow animation to edges
  edges.forEach(edge => {
    const path = edge.querySelector('path');
    if (path) {
      path.style.strokeDasharray = '5, 5';
      path.style.animation = 'flowAnimation 3s linear infinite';
    }
  });
  
  // Add click handlers for nodes
  nodes.forEach(node => {
    node.addEventListener('click', () => {
      // Toggle highlight class
      node.classList.toggle('highlight');
      
      // Find connected edges
      highlightConnectedEdges(diagram, node);
    });
  });
}

function enhanceSequenceDiagram(diagram, container) {
  // Get all actors and messages
  const actors = diagram.querySelectorAll('.actor');
  const messages = diagram.querySelectorAll('.message');
  
  // Add animation classes
  actors.forEach(actor => {
    actor.classList.add('mermaid-step');
  });
  
  messages.forEach((message, index) => {
    message.classList.add('mermaid-step');
    message.style.transitionDelay = `${index * 0.2}s`;
  });
  
  // Add animation controls
  addAnimationControls(diagram, container, 'sequence');
}

function enhanceClassDiagram(diagram, container) {
  // Get all classes
  const classes = diagram.querySelectorAll('.classGroup');
  
  // Add animation classes
  classes.forEach((classGroup, index) => {
    classGroup.classList.add('mermaid-step');
    classGroup.style.transitionDelay = `${index * 0.1}s`;
  });
  
  // Add animation controls
  addAnimationControls(diagram, container, 'class');
}

function enhanceGenericDiagram(diagram, container) {
  // Add basic animations to all elements
  const elements = diagram.querySelectorAll('g');
  
  elements.forEach((element, index) => {
    // Skip container elements
    if (element.querySelector('g')) return;
    
    element.classList.add('mermaid-step');
    element.style.transitionDelay = `${index * 0.05}s`;
  });
}

function addZoomControls(diagram, container) {
  // Create zoom controls container
  const zoomControls = document.createElement('div');
  zoomControls.className = 'mermaid-zoom-controls';
  
  // Create zoom out button
  const zoomOutButton = document.createElement('button');
  zoomOutButton.className = 'mermaid-zoom-button';
  zoomOutButton.innerHTML = '-';
  zoomOutButton.setAttribute('aria-label', 'Zoom out');
  zoomOutButton.setAttribute('title', 'Zoom out');
  
  // Create zoom in button
  const zoomInButton = document.createElement('button');
  zoomInButton.className = 'mermaid-zoom-button';
  zoomInButton.innerHTML = '+';
  zoomInButton.setAttribute('aria-label', 'Zoom in');
  zoomInButton.setAttribute('title', 'Zoom in');
  
  // Create reset zoom button
  const resetZoomButton = document.createElement('button');
  resetZoomButton.className = 'mermaid-zoom-button';
  resetZoomButton.innerHTML = '↻';
  resetZoomButton.setAttribute('aria-label', 'Reset zoom');
  resetZoomButton.setAttribute('title', 'Reset zoom');
  
  // Create fullscreen button
  const fullscreenButton = document.createElement('button');
  fullscreenButton.className = 'mermaid-zoom-button';
  fullscreenButton.innerHTML = '⛶';
  fullscreenButton.setAttribute('aria-label', 'Toggle fullscreen');
  fullscreenButton.setAttribute('title', 'Toggle fullscreen');
  
  // Add buttons to controls
  zoomControls.appendChild(zoomOutButton);
  zoomControls.appendChild(resetZoomButton);
  zoomControls.appendChild(zoomInButton);
  zoomControls.appendChild(fullscreenButton);
  
  // Add controls to container
  container.appendChild(zoomControls);
  
  // Get SVG element
  const svg = diagram.querySelector('svg');
  if (!svg) return;
  
  // Initialize zoom level
  let zoomLevel = 1;
  
  // Add event listeners
  zoomOutButton.addEventListener('click', () => {
    zoomLevel = Math.max(0.5, zoomLevel - 0.1);
    svg.style.transform = `scale(${zoomLevel})`;
    svg.style.transformOrigin = 'center center';
  });
  
  zoomInButton.addEventListener('click', () => {
    zoomLevel = Math.min(2, zoomLevel + 0.1);
    svg.style.transform = `scale(${zoomLevel})`;
    svg.style.transformOrigin = 'center center';
  });
  
  resetZoomButton.addEventListener('click', () => {
    zoomLevel = 1;
    svg.style.transform = 'scale(1)';
    svg.style.transformOrigin = 'center center';
  });
  
  fullscreenButton.addEventListener('click', () => {
    container.classList.toggle('mermaid-fullscreen');
    
    if (container.classList.contains('mermaid-fullscreen')) {
      fullscreenButton.innerHTML = '⮌';
      fullscreenButton.setAttribute('title', 'Exit fullscreen');
      fullscreenButton.setAttribute('aria-label', 'Exit fullscreen');
    } else {
      fullscreenButton.innerHTML = '⛶';
      fullscreenButton.setAttribute('title', 'Enter fullscreen');
      fullscreenButton.setAttribute('aria-label', 'Enter fullscreen');
    }
  });
}

function addNodeInteractivity(diagram, container) {
  // Get all nodes
  const nodes = diagram.querySelectorAll('.node');
  
  // Create tooltip element
  const tooltip = document.createElement('div');
  tooltip.className = 'diagram-tooltip';
  container.appendChild(tooltip);
  
  nodes.forEach(node => {
    // Get node text
    const nodeText = node.querySelector('.label')?.textContent.trim() || 'Node';
    
    // Add hover effect
    node.addEventListener('mouseenter', () => {
      // Show tooltip
      tooltip.textContent = nodeText;
      tooltip.classList.add('visible');
      
      // Position tooltip
      const nodeRect = node.getBoundingClientRect();
      const containerRect = container.getBoundingClientRect();
      
      tooltip.style.left = `${nodeRect.left - containerRect.left + nodeRect.width / 2}px`;
      tooltip.style.top = `${nodeRect.top - containerRect.top - tooltip.offsetHeight - 10}px`;
      
      // Add highlight class
      node.classList.add('highlight');
      
      // Highlight connected edges
      highlightConnectedEdges(diagram, node);
    });
    
    node.addEventListener('mouseleave', () => {
      // Hide tooltip
      tooltip.classList.remove('visible');
      
      // Remove highlight class
      node.classList.remove('highlight');
      
      // Remove highlight from edges
      diagram.querySelectorAll('.edgePath.highlight').forEach(edge => {
        edge.classList.remove('highlight');
      });
    });
  });
}

function highlightConnectedEdges(diagram, node) {
  // Get node ID
  const nodeId = node.id;
  
  // Get all edges
  const edges = diagram.querySelectorAll('.edgePath');
  
  edges.forEach(edge => {
    // Check if edge is connected to node
    const edgePath = edge.querySelector('path');
    if (!edgePath) return;
    
    const edgePathD = edgePath.getAttribute('d');
    
    // Check if edge path contains node ID
    if (edgePathD && edgePathD.includes(nodeId)) {
      edge.classList.add('highlight');
    }
  });
}

function addProgressiveReveal(diagram, container) {
  // Get all nodes and edges
  const nodes = diagram.querySelectorAll('.node');
  const edges = diagram.querySelectorAll('.edgePath');
  
  // Add step class to all elements
  [...nodes, ...edges].forEach(el => {
    el.classList.add('mermaid-step');
  });
  
  // Create intersection observer
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        // Reveal elements progressively
        revealElements(diagram);
        // Disconnect observer after revealing
        observer.disconnect();
      }
    });
  }, { threshold: 0.3 });
  
  // Observe container
  observer.observe(container);
}

function revealElements(diagram) {
  // Get all steps
  const steps = diagram.querySelectorAll('.mermaid-step');
  
  // Reveal each step with delay
  steps.forEach((step, index) => {
    setTimeout(() => {
      step.classList.add('revealed');
    }, index * 100); // 100ms delay between each element
  });
}

function addAnimationControls(diagram, container, type) {
  // Create controls container
  const controls = document.createElement('div');
  controls.className = 'mermaid-animation-controls';
  
  // Create play button
  const playButton = document.createElement('button');
  playButton.className = 'mermaid-animation-button';
  playButton.innerHTML = 'Play';
  playButton.setAttribute('aria-label', 'Play animation');
  
  // Create reset button
  const resetButton = document.createElement('button');
  resetButton.className = 'mermaid-animation-button';
  resetButton.innerHTML = 'Reset';
  resetButton.setAttribute('aria-label', 'Reset animation');
  
  // Create speed control
  const speedControl = document.createElement('div');
  speedControl.className = 'mermaid-animation-speed';
  
  const speedLabel = document.createElement('span');
  speedLabel.className = 'mermaid-animation-speed-label';
  speedLabel.innerHTML = 'Speed:';
  
  const speedInput = document.createElement('input');
  speedInput.className = 'mermaid-animation-speed-input';
  speedInput.type = 'range';
  speedInput.min = '0.5';
  speedInput.max = '2';
  speedInput.step = '0.1';
  speedInput.value = '1';
  
  speedControl.appendChild(speedLabel);
  speedControl.appendChild(speedInput);
  
  // Add buttons to controls
  controls.appendChild(playButton);
  controls.appendChild(resetButton);
  controls.appendChild(speedControl);
  
  // Add controls to container
  container.appendChild(controls);
  
  // Animation state
  let isPlaying = false;
  let animationSpeed = 1;
  
  // Add event listeners
  playButton.addEventListener('click', () => {
    if (isPlaying) {
      pauseAnimation(diagram, type);
      playButton.innerHTML = 'Play';
    } else {
      playAnimation(diagram, type, animationSpeed);
      playButton.innerHTML = 'Pause';
    }
    isPlaying = !isPlaying;
  });
  
  resetButton.addEventListener('click', () => {
    resetAnimation(diagram, type);
    isPlaying = false;
    playButton.innerHTML = 'Play';
  });
  
  speedInput.addEventListener('input', () => {
    animationSpeed = parseFloat(speedInput.value);
    if (isPlaying) {
      pauseAnimation(diagram, type);
      playAnimation(diagram, type, animationSpeed);
    }
  });
}

function playAnimation(diagram, type, speed) {
  // Reset animation first
  resetAnimation(diagram, type);
  
  // Get elements to animate
  let elements = [];
  
  switch (type) {
    case 'sequence':
      elements = diagram.querySelectorAll('.message');
      break;
    case 'class':
      elements = diagram.querySelectorAll('.classGroup');
      break;
    default:
      elements = diagram.querySelectorAll('.mermaid-step');
      break;
  }
  
  // Animate elements
  elements.forEach((element, index) => {
    setTimeout(() => {
      element.classList.add('revealed');
    }, index * (500 / speed)); // Adjust timing based on speed
  });
}

function pauseAnimation(diagram, type) {
  // Pause by freezing current state
  const elements = diagram.querySelectorAll('.mermaid-step');
  elements.forEach(element => {
    const isRevealed = element.classList.contains('revealed');
    element.style.transition = 'none';
    element.classList.toggle('revealed', isRevealed);
    
    // Force reflow
    void element.offsetWidth;
    
    // Restore transition
    element.style.transition = '';
  });
}

function resetAnimation(diagram, type) {
  // Hide all elements
  const elements = diagram.querySelectorAll('.mermaid-step');
  elements.forEach(element => {
    element.classList.remove('revealed');
  });
}

function initializeSpecificAnimation(diagram, container, animationType, speed) {
  console.log(`Initializing ${animationType} animation with speed ${speed}...`);
  
  switch (animationType) {
    case 'flow':
      initializeFlowAnimation(diagram, container, speed);
      break;
    case 'step-by-step':
      initializeStepByStepAnimation(diagram, container, speed);
      break;
    case 'highlight-path':
      initializeHighlightPathAnimation(diagram, container, speed);
      break;
    case 'pulse':
      initializePulseAnimation(diagram, container, speed);
      break;
    default:
      console.log(`Unknown animation type: ${animationType}`);
      break;
  }
}

function initializeFlowAnimation(diagram, container, speed) {
  // Get all edges
  const edges = diagram.querySelectorAll('.edgePath path');
  
  // Apply flow animation
  edges.forEach(edge => {
    edge.style.strokeDasharray = '5, 5';
    edge.style.animation = `flowAnimation ${3 / speed}s linear infinite`;
  });
}

function initializeStepByStepAnimation(diagram, container, speed) {
  // Get all nodes
  const nodes = diagram.querySelectorAll('.node');
  
  // Add step class
  nodes.forEach((node, index) => {
    node.classList.add('mermaid-step');
    node.style.transitionDelay = `${index * (0.5 / speed)}s`;
  });
  
  // Add animation controls
  addAnimationControls(diagram, container, 'step-by-step');
}

function initializeHighlightPathAnimation(diagram, container, speed) {
  // Get all nodes and edges
  const nodes = diagram.querySelectorAll('.node');
  const edges = diagram.querySelectorAll('.edgePath');
  
  // Create path array
  const path = [];
  
  // Find start node (usually the first one)
  if (nodes.length > 0) {
    path.push(nodes[0]);
    
    // Add animation controls
    const controls = document.createElement('div');
    controls.className = 'mermaid-animation-controls';
    
    const playButton = document.createElement('button');
    playButton.className = 'mermaid-animation-button';
    playButton.innerHTML = 'Highlight Path';
    
    controls.appendChild(playButton);
    container.appendChild(controls);
    
    playButton.addEventListener('click', () => {
      // Reset any existing highlights
      nodes.forEach(node => node.classList.remove('highlight'));
      edges.forEach(edge => edge.classList.remove('highlight'));
      
      // Highlight path
      highlightPath(diagram, path, speed);
    });
  }
}

function initializePulseAnimation(diagram, container, speed) {
  // Get all nodes
  const nodes = diagram.querySelectorAll('.node');
  
  // Add pulse class
  nodes.forEach(node => {
    node.classList.add('pulse');
    
    // Adjust animation speed
    const elements = node.querySelectorAll('rect, circle, polygon, ellipse');
    elements.forEach(el => {
      el.style.animation = `pulseAnimation ${2 / speed}s ease-in-out infinite`;
    });
  });
}

function highlightPath(diagram, path, speed) {
  // Highlight nodes in sequence
  path.forEach((node, index) => {
    setTimeout(() => {
      node.classList.add('highlight');
      
      // Find connected edges
      if (index < path.length - 1) {
        const nextNode = path[index + 1];
        const edges = diagram.querySelectorAll('.edgePath');
        
        edges.forEach(edge => {
          const edgePath = edge.querySelector('path');
          if (!edgePath) return;
          
          const edgePathD = edgePath.getAttribute('d');
          
          // Check if edge connects current node to next node
          if (edgePathD && edgePathD.includes(node.id) && edgePathD.includes(nextNode.id)) {
            edge.classList.add('highlight');
          }
        });
      }
    }, index * (1000 / speed));
  });
}

export default {};
