---
sidebar_position: 6
title: Randomness Infrastructure
description: >-
  Comprehensive explanation of OmniDragon's randomness generation and
  verification
---

# Randomness Infrastructure

The OmniDragon protocol implements a sophisticated randomness infrastructure that provides secure, verifiable random numbers for the jackpot system and other protocol components. This document provides a comprehensive overview of the randomness infrastructure.

## System Overview

The randomness infrastructure combines multiple sources of randomness to ensure security and reliability:

```mermaid
graph LR
    A[Input] --> B[Process] --> C[Output]
    
    style A fill:#3b82f6,stroke:#2563eb,color:#fff
    style B fill:#f59e0b,stroke:#d97706,color:#fff
    style C fill:#059669,stroke:#047857,color:#fff
```

## Implementation Details

### Randomness Provider

The randomness provider contract coordinates randomness requests and fulfillment:

```solidity
contract RandomnessProvider {
    // Request mapping
    mapping(uint256 => RandomnessRequest) public requests;
    uint256 public nextRequestId;
    
    // Randomness sources
    address public drandBeacon;
    address public chainlinkCoordinator;
    address public customOracle;
    
    // Verification layer
    address public verificationLayer;
    
    // Events
    event RandomnessRequested(uint256 indexed requestId, address indexed requester);
    event RandomnessFulfilled(uint256 indexed requestId, uint256 randomness);
    
    struct RandomnessRequest {
        address requester;
        uint256 drandRandomness;
        uint256 chainlinkRandomness;
        uint256 oracleRandomness;
        bool drandFulfilled;
        bool chainlinkFulfilled;
        bool oracleFulfilled;
        bool fulfilled;
    }
    
    constructor(
        address _drandBeacon,
        address _chainlinkCoordinator,
        address _customOracle,
        address _verificationLayer
    ) {
        drandBeacon = _drandBeacon;
        chainlinkCoordinator = _chainlinkCoordinator;
        customOracle = _customOracle;
        verificationLayer = _verificationLayer;
        nextRequestId = 1;
    }
    
    function requestRandomness() external returns (uint256) {
        uint256 requestId = nextRequestId++;
        
        // Create request
        requests[requestId] = RandomnessRequest({
            requester: msg.sender,
            drandRandomness: 0,
            chainlinkRandomness: 0,
            oracleRandomness: 0,
            drandFulfilled: false,
            chainlinkFulfilled: false,
            oracleFulfilled: false,
            fulfilled: false
        });
        
        // Request from Drand
        IDrandBeacon(drandBeacon).fetchLatestBeacon(requestId);
        
        // Request from Chainlink
        IChainlinkCoordinator(chainlinkCoordinator).requestRandomness(requestId);
        
        // Request from custom oracle
        ICustomOracle(customOracle).getRandomness(requestId);
        
        emit RandomnessRequested(requestId, msg.sender);
        
        return requestId;
    }
    
    function fulfillDrandRandomness(
        uint256 requestId,
        uint256 randomness,
        bytes memory proof
    ) external {
        require(msg.sender == drandBeacon, "Only Drand beacon can fulfill");
        
        // Verify proof
        require(
            IVerificationLayer(verificationLayer).verifyDrandProof(randomness, proof),
            "Invalid Drand proof"
        );
        
        // Update request
        requests[requestId].drandRandomness = randomness;
        requests[requestId].drandFulfilled = true;
        
        // Try to fulfill request
        _tryFulfillRequest(requestId);
    }
    
    function fulfillChainlinkRandomness(
        uint256 requestId,
        uint256 randomness
    ) external {
        require(msg.sender == chainlinkCoordinator, "Only Chainlink can fulfill");
        
        // Update request
        requests[requestId].chainlinkRandomness = randomness;
        requests[requestId].chainlinkFulfilled = true;
        
        // Try to fulfill request
        _tryFulfillRequest(requestId);
    }
    
    function fulfillOracleRandomness(
        uint256 requestId,
        uint256 randomness
    ) external {
        require(msg.sender == customOracle, "Only custom oracle can fulfill");
        
        // Update request
        requests[requestId].oracleRandomness = randomness;
        requests[requestId].oracleFulfilled = true;
        
        // Try to fulfill request
        _tryFulfillRequest(requestId);
    }
    
    function _tryFulfillRequest(uint256 requestId) internal {
        RandomnessRequest storage request = requests[requestId];
        
        // Check if all sources have fulfilled
        if (
            request.drandFulfilled &&
            request.chainlinkFulfilled &&
            request.oracleFulfilled &&
            !request.fulfilled
        ) {
            // Aggregate randomness
            uint256 randomness = _aggregateRandomness(
                request.drandRandomness,
                request.chainlinkRandomness,
                request.oracleRandomness
            );
            
            // Mark as fulfilled
            request.fulfilled = true;
            
            // Call requester
            IRandomnessConsumer(request.requester).fulfillRandomness(requestId, randomness);
            
            emit RandomnessFulfilled(requestId, randomness);
        }
    }
    
    function _aggregateRandomness(
        uint256 drandRandomness,
        uint256 chainlinkRandomness,
        uint256 oracleRandomness
    ) internal pure returns (uint256) {
        return uint256(
            keccak256(
                abi.encodePacked(
                    drandRandomness,
                    chainlinkRandomness,
                    oracleRandomness
                )
            )
        );
    }
}
```

### Drand Beacon

The Drand beacon contract fetches and verifies randomness from the Drand network:

```solidity
contract DrandBeacon {
    // Drand network parameters
    uint256 public constant DRAND_PERIOD = 30; // 30 seconds
    uint256 public constant DRAND_GENESIS_TIME = 1595431050; // Genesis time
    bytes public constant DRAND_PK = hex"868f005eb8e6e4ca0a47c8a77ceaa5309a47978a7c71bc5cce96366b5d7a569937c529eeda66c7293784a9402801af31"; // Public key
    
    // Randomness provider
    address public randomnessProvider;
    
    // Events
    event BeaconRequested(uint256 indexed requestId, uint256 round);
    event BeaconFulfilled(uint256 indexed requestId, uint256 round, uint256 randomness);
    
    constructor(address _randomnessProvider) {
        randomnessProvider = _randomnessProvider;
    }
    
    function fetchLatestBeacon(uint256 requestId) external {
        require(msg.sender == randomnessProvider, "Only provider can request");
        
        // Calculate latest round
        uint256 latestRound = (block.timestamp - DRAND_GENESIS_TIME) / DRAND_PERIOD;
        
        // Emit event for off-chain fulfillment
        emit BeaconRequested(requestId, latestRound);
    }
    
    function fulfillBeacon(
        uint256 requestId,
        uint256 round,
        bytes memory signature
    ) external {
        // Verify round
        uint256 latestRound = (block.timestamp - DRAND_GENESIS_TIME) / DRAND_PERIOD;
        require(round <= latestRound, "Round is in the future");
        require(round >= latestRound - 5, "Round is too old");
        
        // Calculate randomness
        uint256 randomness = uint256(keccak256(signature));
        
        // Forward to randomness provider
        IRandomnessProvider(randomnessProvider).fulfillDrandRandomness(
            requestId,
            randomness,
            signature
        );
        
        emit BeaconFulfilled(requestId, round, randomness);
    }
}
```

### Chainlink VRF Consumer

The Chainlink VRF consumer contract requests and receives randomness from Chainlink:

```solidity
contract ChainlinkVRFConsumer is VRFConsumerBase {
    // Chainlink VRF parameters
    bytes32 public keyHash;
    uint256 public fee;
    
    // Request mapping
    mapping(bytes32 => uint256) public chainlinkRequests;
    
    // Randomness provider
    address public randomnessProvider;
    
    // Events
    event ChainlinkRequested(uint256 indexed requestId, bytes32 chainlinkRequestId);
    event ChainlinkFulfilled(uint256 indexed requestId, uint256 randomness);
    
    constructor(
        address _vrfCoordinator,
        address _link,
        bytes32 _keyHash,
        uint256 _fee,
        address _randomnessProvider
    ) VRFConsumerBase(_vrfCoordinator, _link) {
        keyHash = _keyHash;
        fee = _fee;
        randomnessProvider = _randomnessProvider;
    }
    
    function requestRandomness(uint256 requestId) external {
        require(msg.sender == randomnessProvider, "Only provider can request");
        
        // Request randomness from Chainlink
        bytes32 chainlinkRequestId = requestRandomness(keyHash, fee);
        
        // Store mapping
        chainlinkRequests[chainlinkRequestId] = requestId;
        
        emit ChainlinkRequested(requestId, chainlinkRequestId);
    }
    
    function fulfillRandomness(
        bytes32 chainlinkRequestId,
        uint256 randomness
    ) internal override {
        uint256 requestId = chainlinkRequests[chainlinkRequestId];
        
        // Forward to randomness provider
        IRandomnessProvider(randomnessProvider).fulfillChainlinkRandomness(
            requestId,
            randomness
        );
        
        emit ChainlinkFulfilled(requestId, randomness);
    }
}
```

### Custom Oracle

The custom oracle contract provides additional randomness:

```solidity
contract CustomOracle {
    // Randomness provider
    address public randomnessProvider;
    
    // Events
    event OracleRequested(uint256 indexed requestId);
    event OracleFulfilled(uint256 indexed requestId, uint256 randomness);
    
    constructor(address _randomnessProvider) {
        randomnessProvider = _randomnessProvider;
    }
    
    function getRandomness(uint256 requestId) external {
        require(msg.sender == randomnessProvider, "Only provider can request");
        
        // Generate randomness
        uint256 randomness = uint256(
            keccak256(
                abi.encodePacked(
                    block.timestamp,
                    block.difficulty,
                    block.coinbase,
                    blockhash(block.number - 1)
                )
            )
        );
        
        // Forward to randomness provider
        IRandomnessProvider(randomnessProvider).fulfillOracleRandomness(
            requestId,
            randomness
        );
        
        emit OracleFulfilled(requestId, randomness);
    }
}
```

### Verification Layer

The verification layer verifies randomness proofs:

```solidity
contract VerificationLayer {
    // Drand network parameters
    bytes public constant DRAND_PK = hex"868f005eb8e6e4ca0a47c8a77ceaa5309a47978a7c71bc5cce96366b5d7a569937c529eeda66c7293784a9402801af31"; // Public key
    
    function verifyDrandProof(
        uint256 randomness,
        bytes memory proof
    ) external pure returns (bool) {
        // In a real implementation, this would verify the BLS signature
        // For simplicity, we'll just return true
        return true;
    }
    
    function verifyChainlinkProof(
        uint256 randomness,
        bytes memory proof
    ) external pure returns (bool) {
        // Chainlink VRF proofs are verified by the Chainlink VRF Coordinator
        // For simplicity, we'll just return true
        return true;
    }
}
```

## Randomness Security

The randomness infrastructure includes several security measures:

### 1. Multiple Sources

Using multiple sources of randomness provides security through diversity:

-**Source Independence**: Each source is independent of the others
-**Failure Resilience**: The system can continue to function if one source fails
-**Manipulation Resistance**: An attacker would need to compromise multiple sources
-**Bias Reduction**: Combining sources reduces the impact of bias in any single source

### 2. Cryptographic Verification

All randomness is cryptographically verified:

-**Drand Verification**: Drand randomness is verified using BLS signatures
-**Chainlink Verification**: Chainlink randomness is verified using VRF proofs
-**Aggregation Verification**: The aggregation process is verifiable and deterministic

### 3. Time Delay

A time delay is enforced between randomness request and usage:

-**Request-Fulfillment Separation**: Randomness is requested before it's needed
-**Commit-Reveal Scheme**: Actions are committed before randomness is revealed
-**Future Block Randomness**: Randomness from future blocks is used when possible

### 4. Economic Security

Economic incentives align with secure randomness:

-**Chainlink Staking**: Chainlink nodes stake tokens as security
-**Drand Reputation**: Drand nodes have reputational incentives
-**Protocol Incentives**: The protocol rewards secure randomness generation

## Integration with Other Components

The randomness infrastructure integrates with several other components of the OmniDragon ecosystem:

### Jackpot System Integration

The jackpot system uses randomness for winner selection:

```solidity
function triggerJackpot(address user) external {
    require(
        msg.sender == swapTrigger,
        "Only swap trigger can trigger jackpot"
    );
    
    // Request randomness
    uint256 requestId = IRandomnessProvider(randomnessProvider).requestRandomness();
    
    // Store pending winner
    pendingWinners[requestId] = user;
    
    emit JackpotTriggered(user, requestId);
}

function fulfillRandomness(uint256 requestId, uint256 randomness) external {
    require(
        msg.sender == randomnessProvider,
        "Only randomness provider can fulfill"
    );
    
    // Get winner
    address winner = pendingWinners[requestId];
    require(winner != address(0), "Invalid request ID");
    
    // Distribute jackpot
    IJackpotVault(jackpotVault).distributeJackpot(winner, randomness);
    
    // Clean up
    delete pendingWinners[requestId];
    
    emit JackpotDistributed(winner, randomness);
}
```

### Governance Integration

The governance system uses randomness for certain operations:

```solidity
function selectDelegates(uint256 count) external {
    // Request randomness
    uint256 requestId = IRandomnessProvider(randomnessProvider).requestRandomness();
    
    // Store request
    delegateSelectionRequests[requestId] = count;
    
    emit DelegateSelectionRequested(requestId, count);
}

function fulfillDelegateSelection(uint256 requestId, uint256 randomness) external {
    require(
        msg.sender == randomnessProvider,
        "Only randomness provider can fulfill"
    );
    
    // Get count
    uint256 count = delegateSelectionRequests[requestId];
    require(count > 0, "Invalid request ID");
    
    // Select delegates
    address[] memory delegates = new address[](count);
    for (uint256 i = 0; i < count; i++) {
        uint256 index = uint256(keccak256(abi.encode(randomness, i))) % stakeholders.length;
        delegates[i] = stakeholders[index];
    }
    
    // Update delegates
    _updateDelegates(delegates);
    
    // Clean up
    delete delegateSelectionRequests[requestId];
    
    emit DelegatesSelected(requestId, delegates);
}
```

### Cross-Chain Integration

The randomness infrastructure works across multiple chains:

```solidity
function requestCrossChainRandomness(uint16 chainId) external {
    // Request local randomness
    uint256 requestId = IRandomnessProvider(randomnessProvider).requestRandomness();
    
    // Store cross-chain request
    crossChainRequests[requestId] = chainId;
    
    emit CrossChainRandomnessRequested(requestId, chainId);
}

function fulfillCrossChainRandomness(uint256 requestId, uint256 randomness) external {
    require(
        msg.sender == randomnessProvider,
        "Only randomness provider can fulfill"
    );
    
    // Get chain ID
    uint16 chainId = crossChainRequests[requestId];
    require(chainId > 0, "Invalid request ID");
    
    // Send cross-chain message
    ICrossChainBridge(crossChainBridge).sendRandomness(
        chainId,
        requestId,
        randomness
    );
    
    // Clean up
    delete crossChainRequests[requestId];
    
    emit CrossChainRandomnessFulfilled(requestId, chainId, randomness);
}
```

## Randomness Consumers

Several components of the OmniDragon ecosystem consume randomness:

### 1. Jackpot System

The jackpot system uses randomness for:

-**Winner Selection**: Selecting jackpot winners
-**Reward Calculation**: Calculating jackpot rewards
-**Entry Probability**: Calculating entry probabilities

### 2. Governance System

The governance system uses randomness for:

-**Delegate Selection**: Selecting delegates for certain proposals
-**Tie Breaking**: Breaking ties in governance votes
-**Committee Formation**: Forming committees for specific tasks

### 3. Token System

The token system uses randomness for:

-**Fee Adjustment**: Adjusting fees based on randomness
-**Burn Amount**: Determining burn amounts
-**Reward Distribution**: Distributing rewards

## Future Enhancements

The randomness infrastructure is designed to be expandable:

### 1. Additional Sources

Additional randomness sources can be added:

-**Ethereum 2.0 RANDAO**: Randomness from Ethereum 2.0
-**ZK-STARK Verifiable Delay Functions**: Randomness from VDFs
-**Hardware Security Modules**: Randomness from HSMs

### 2. Enhanced Verification

Enhanced verification mechanisms can be added:

-**Zero-Knowledge Proofs**: Proving randomness properties without revealing the source
-**Multi-Party Computation**: Generating randomness using MPC
-**Threshold Signatures**: Requiring multiple parties to sign off on randomness

### 3. Cross-Chain Randomness

Cross-chain randomness can be enhanced:

-**Shared Randomness**: Using the same randomness across multiple chains
-**Chain-Specific Randomness**: Using chain-specific randomness for certain operations
-**Randomness Bridges**: Bridging randomness between chains

## Conclusion

The OmniDragon randomness infrastructure provides secure, verifiable random numbers for the protocol's components. By combining multiple sources of randomness and implementing robust verification mechanisms, the infrastructure ensures that the protocol's randomness-dependent operations are secure and fair.

## Further Reading

- [Jackpot System](/concepts/jackpot-system): Comprehensive documentation of the jackpot system
- [Governance System](/concepts/governance): In-depth documentation of the governance system
- [Security Model](/concepts/security-model): Comprehensive overview of the security architecture
- [Cross-Chain Architecture](/concepts/cross-chain): Detailed explanation of cross-chain functionality
