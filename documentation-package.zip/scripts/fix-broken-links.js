#!/usr/bin/env node

/**
 * Fix Broken Links
 * 
 * This script fixes broken links in the documentation by creating missing files
 * or updating incorrect links.
 */

const fs = require('fs');
const path = require('path');

console.log('🔗 FIXING BROKEN LINKS');
console.log('=====================\n');

// Configuration
const config = {
  backupDir: 'backups',
  brokenLinks: [
    // Broken links from the error message
    { source: '/concepts/cross-chain', target: '/concepts/token-system', action: 'create' },
    { source: '/concepts/cross-chain', target: '/concepts/jackpot', action: 'create' },
    { source: '/concepts/cross-chain', target: '/concepts/token-system#governance', action: 'update' },
    { source: '/concepts/interactive-learning', target: '/concepts/jackpot', action: 'create' },
    { source: '/concepts/randomness', target: '/concepts/jackpot', action: 'create' },
    { source: '/concepts/randomness', target: '/concepts/token-system#governance', action: 'update' },
    { source: '/concepts/security-model', target: '/concepts/token-system', action: 'create' },
    { source: '/concepts/security-model', target: '/concepts/jackpot', action: 'create' },
    { source: '/guides/getting-started/developer-setup', target: '../../../docs/resources/faq.md', action: 'update' },
    { source: '/guides/getting-started/quick-start', target: '/getting-started/developer-setup', action: 'update' },
    { source: '/guides/getting-started/quick-start', target: '../../../docs/resources/faq.md', action: 'update' },
    { source: '/partner/case-studies/chainlink', target: '/integrations/chainlink/vrf', action: 'create' },
    { source: '/partner/case-studies/drand', target: '/integrations/drand/setup', action: 'create' },
    { source: '/partner/case-studies/drand', target: '/integrations/drand/usage', action: 'create' },
    { source: '/partner/case-studies/layerzero', target: '/integrations/LayerZero/setup', action: 'create' },
    { source: '/reference/api/rest-api', target: '../../../docs/contracts/core/omnidragon.md', action: 'update' },
    { source: '/reference/api/rest-api', target: '../../../docs/guide/developer-guide.mdx', action: 'update' },
    { source: '/reference/api/rest-api', target: '../security/AUDIT_DOCUMENTATION_SUMMARY.md', action: 'update' }
  ]
};

// Create backup directory if it doesn't exist
if (!fs.existsSync(config.backupDir)) {
  fs.mkdirSync(config.backupDir, { recursive: true });
}

// Backup a file
function backupFile(filePath) {
  const backupPath = path.join(config.backupDir, path.basename(filePath) + '.backup');
  fs.copyFileSync(filePath, backupPath);
  console.log(`  ✅ Backed up ${filePath} to ${backupPath}`);
  return backupPath;
}

// Get the full path of a file from its URL path
function getFilePath(urlPath) {
  // Remove leading slash and add .md extension if not present
  let filePath = urlPath.startsWith('/') ? urlPath.substring(1) : urlPath;
  
  // Check if it's a docs-new path
  if (filePath.startsWith('concepts/') || 
      filePath.startsWith('guides/') || 
      filePath.startsWith('partner/') || 
      filePath.startsWith('reference/') || 
      filePath.startsWith('integrations/')) {
    filePath = path.join('docs-new', filePath);
  } else {
    filePath = path.join('docs', filePath);
  }
  
  // Add .md extension if not present
  if (!filePath.endsWith('.md') && !filePath.endsWith('.mdx')) {
    filePath += '.md';
  }
  
  return filePath;
}

// Create a missing file
function createMissingFile(targetPath, sourcePath) {
  console.log(`Creating missing file: ${targetPath}`);
  
  // Get the directory of the target file
  const targetDir = path.dirname(targetPath);
  
  // Create the directory if it doesn't exist
  if (!fs.existsSync(targetDir)) {
    fs.mkdirSync(targetDir, { recursive: true });
    console.log(`  ✅ Created directory: ${targetDir}`);
  }
  
  // Get the file name without extension
  const fileName = path.basename(targetPath, path.extname(targetPath));
  
  // Create the file content
  const content = `---
title: ${fileName.charAt(0).toUpperCase() + fileName.slice(1).replace(/-/g, ' ')}
description: Documentation for ${fileName.replace(/-/g, ' ')}
---

# ${fileName.charAt(0).toUpperCase() + fileName.slice(1).replace(/-/g, ' ')}

This documentation is currently being developed. Please check back later for updates.

## Overview

This section provides information about ${fileName.replace(/-/g, ' ')}.

## Related Resources

- [Documentation Home](/)
- [Concepts](/concepts/overview)
`;
  
  // Write the file
  fs.writeFileSync(targetPath, content);
  console.log(`  ✅ Created file: ${targetPath}`);
  
  return true;
}

// Update a link in a file
function updateLink(filePath, oldLink, newLink) {
  console.log(`Updating link in ${filePath}: ${oldLink} -> ${newLink}`);
  
  // Check if the file exists
  if (!fs.existsSync(filePath)) {
    console.error(`  ❌ File not found: ${filePath}`);
    return false;
  }
  
  try {
    // Backup the file
    backupFile(filePath);
    
    // Read the file
    const content = fs.readFileSync(filePath, 'utf8');
    
    // Replace the link
    const updatedContent = content.replace(
      new RegExp(`\\[([^\\]]+)\\]\\(${oldLink.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\)`, 'g'),
      `[$1](${newLink})`
    );
    
    // Write the updated content
    fs.writeFileSync(filePath, updatedContent);
    
    console.log(`  ✅ Updated link in ${filePath}`);
    return true;
  } catch (error) {
    console.error(`  ❌ Error updating link in ${filePath}: ${error.message}`);
    return false;
  }
}

// Fix a broken link
function fixBrokenLink(source, target, action) {
  console.log(`Fixing broken link: ${source} -> ${target} (${action})`);
  
  // Get the full paths
  const sourcePath = getFilePath(source);
  const targetPath = getFilePath(target);
  
  // Check if the source file exists
  if (!fs.existsSync(sourcePath)) {
    console.error(`  ❌ Source file not found: ${sourcePath}`);
    return false;
  }
  
  // Fix the link based on the action
  switch (action) {
    case 'create':
      // Create the target file if it doesn't exist
      if (!fs.existsSync(targetPath)) {
        return createMissingFile(targetPath, sourcePath);
      } else {
        console.log(`  ℹ️ Target file already exists: ${targetPath}`);
        return true;
      }
    
    case 'update':
      // Calculate the relative path from source to target
      const sourceDir = path.dirname(sourcePath);
      const targetRelative = path.relative(sourceDir, targetPath);
      
      // Update the link in the source file
      return updateLink(sourcePath, target, targetRelative);
    
    default:
      console.error(`  ❌ Unknown action: ${action}`);
      return false;
  }
}

// Main function
function main() {
  console.log('Starting to fix broken links...\n');
  
  let fixedCount = 0;
  let errorCount = 0;
  
  // Fix each broken link
  config.brokenLinks.forEach(link => {
    const success = fixBrokenLink(link.source, link.target, link.action);
    
    if (success) {
      fixedCount++;
    } else {
      errorCount++;
    }
    
    console.log(''); // Add a blank line between links
  });
  
  console.log('\n📊 Summary:');
  console.log(`  ✅ Fixed ${fixedCount} broken links`);
  console.log(`  ❌ Failed to fix ${errorCount} broken links`);
  
  if (errorCount > 0) {
    console.log('\n⚠️ Some links could not be fixed. Please check the error messages above.');
  } else {
    console.log('\n🎉 All links have been fixed successfully!');
  }
  
  console.log('\nTo verify the fixes, run:');
  console.log('  npm run build');
}

// Run the main function
main();
