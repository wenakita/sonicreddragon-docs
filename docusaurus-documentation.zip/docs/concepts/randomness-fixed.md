---
sidebar_position: 5
title: Secure Randomness System
description: Detailed explanation of this concept
---

# Secure Randomness System

The OmniDragon protocol incorporates a robust multi-source randomness system to ensure fair and unpredictable outcomes for jackpot distributions and other protocol operations.

## Randomness Architecture

The protocol implements a layered architecture for randomness generation:

```mermaid
flowchart TB
%% Define main components
    subgraph CoreRNG["Core Randomness Components"]
        direction TB
        INTERFACE["IRandomnessConsumer"]:::interface
        AGGREGATOR["RandomnessAggregator"]:::core
        FALLBACK["FallbackSystem"]:::core
    subgraph Sources["Randomness Sources"]
        direction LR
        CHAINLINK["Chainlink VRF"]:::source
        DRAND["Drand Network"]:::source
        ARB_VRF["Arbitrum VRF"]:::source
        INTERNAL["Internal PRNG"]:::source
    subgraph Consumers["Randomness Consumers"]
        direction LR
        JACKPOT["Jackpot System"]:::consumer
        TRIGGER["Trigger System"]:::consumer
        SELECTION["Winner Selection"]:::consumer
        LOTTERY["Lottery System"]:::consumer
        %% Connect the systems
        Sources -->|"Provide seeds"| AGGREGATOR
        INTERFACE -.->|"Implemented by"| Consumers
        AGGREGATOR -->|"Provides randomness"| Consumers
        FALLBACK -->|"Backup mechanism"| AGGREGATOR
        %% Apply styling
    classDef interface fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef core fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef source fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef consumer fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
        %% Style subgraphs
        style CoreRNG fill:#e3f2fd,stroke:#bbdefb,color:#1565c0
        style Sources fill:#f3e5f5,stroke:#e1bee7,color:#6a1b9a
        style Consumers fill:#fff8e1,stroke:#ffecb3,color:#ff8f00
    end
    end
    end
```

## Randomness Sources

OmniDragon leverages multiple randomness sources to ensure reliability and unpredictability:

### Chainlink VRF

Chainlink's Verifiable Random Function (VRF) provides cryptographically secure randomness that can be verified on-chain:

```solidity
function requestRandomnessFromChainlink() internal returns (uint256 requestId) {
    return vrfCoordinator.requestRandomWords(
        keyHash,
        subscriptionId,
        requestConfirmations,
        callbackGasLimit,
        1 // Number of random words
    );
}

function fulfillRandomWords(uint256 requestId, uint256[] memory randomWords) 
    internal override 
{
    // Process the received randomness
    uint256 randomValue = randomWords[0];
    
    // Store or use the random value
    emit RandomnessReceived(requestId, randomValue);
}
```

### Drand Network

The Drand network provides publicly verifiable, unbiased, and unpredictable randomness:

```solidity
function verifyAndUseDrandRandomness(
    uint256 roundNumber,
    bytes calldata signature,
    bytes calldata previousSignature
) external onlyOracle returns (bytes32 randomness) {
    // Verify signature with drand public key
    require(drandVerifier.verify(roundNumber, signature, previousSignature), 
        "Invalid drand proof");
    
    // Extract randomness from signature
    randomness = keccak256(signature);
    
    // Use the randomness
    emit DrandRandomnessReceived(roundNumber, randomness);
    return randomness;
}
```

### Arbitrum VRF

Arbitrum's native VRF provides randomness specifically optimized for the Arbitrum chain:

```solidity
function requestArbitrumRandomness() internal returns (uint256 requestId) {
    return arbitrumVRF.requestRandomWords(callbackGasLimit, 1);
}

function fulfillRandomWords(uint256 requestId, uint256[] memory randomWords) 
    internal override 
{
    // Process the received randomness
    uint256 randomValue = randomWords[0];
    
    // Store or use the random value
    emit ArbitrumRandomnessReceived(requestId, randomValue);
}
```

### Internal PRNG

As a fallback mechanism, an internal pseudo-randomness generator combines on-chain data:

```solidity
function generateFallbackRandomness() internal view returns (uint256) {
    return uint256(keccak256(abi.encodePacked(
        blockhash(block.number - 1),
        block.timestamp,
        msg.sender,
        address(this),
        randomnessSeed
    )));
}
```

## Randomness Flow

The process of requesting and receiving randomness follows this sequence:

```mermaid
sequenceDiagram
participant Consumer as Randomness Consumer
participant Aggregator as Randomness Aggregator
participant Chainlink as Chainlink VRF
participant Drand as Drand Network
participant Arbitrum as Arbitrum VRF

    %% Style regions
    rect rgb(233, 245, 255)
    note over Consumer,Aggregator: Request Phase
    Consumer->>+Aggregator: requestRandomness()
    Aggregator ->> Aggregator: Generate requestId

    alt Primary Source (Chainlink)
    Aggregator->>+Chainlink: requestRandomWords()
        Chainlink-->>-Aggregator: Chainlink requestId
    Aggregator ->> Aggregator: Map requestIds
    else Secondary Source (Drand)
    Aggregator->>+Drand: Request via oracle
        Drand-->>-Aggregator: Pending (off-chain)
    else Tertiary Source (Arbitrum VRF)
    Aggregator->>+Arbitrum: requestRandomWords()
        Arbitrum-->>-Aggregator: Arbitrum requestId
    Aggregator-->>-Consumer: OmniDragon requestId

    rect rgb(245, 235, 255)
    note over Aggregator: Fulfillment Phase
    alt Chainlink Fulfillment
    Chainlink->>+Aggregator: fulfillRandomWords(requestId, randomWords)
    Aggregator ->> Aggregator: Store Chainlink randomness
    else Drand Fulfillment
    Drand->>+Aggregator: fulfillDrandRandomness(roundNumber, signature)
    Aggregator ->> Aggregator: Verify and store Drand randomness
    else Arbitrum Fulfillment
    Arbitrum->>+Aggregator: fulfillRandomWords(requestId, randomWords)
    Aggregator ->> Aggregator: Store Arbitrum randomness
    rect rgb(242, 255, 235)
    note over Consumer,Aggregator: Consumption Phase
    Aggregator ->> Aggregator: Combine randomness from sources
    Aggregator->>+Consumer: fulfillRandomness(requestId, randomValue)
    Consumer ->> Consumer: Process randomness
    Consumer-->>-Aggregator: Randomness consumed
```

## Randomness Security Measures

The OmniDragon randomness system implements several security measures:

### Multi-Source Aggregation

Randomness is derived from multiple independent sources to prevent single points of failure:

```solidity
function aggregateRandomness(
    uint256 chainlinkRandom,
    bytes32 drandRandom,
    uint256 arbitrumRandom
) internal pure returns (uint256) {
    return uint256(keccak256(abi.encodePacked(
        chainlinkRandom,
        drandRandom,
        arbitrumRandom
    )));
}
```

### Source Verification

Each randomness source is verified for authenticity:

1.**Chainlink VRF**: Uses cryptographic verification built into the VRF
2.**Drand**: Verifies threshold signatures against the Drand public key
3.**Arbitrum VRF**: Verifies the randomness comes from the Arbitrum VRF system

### Fallback Mechanisms

If primary randomness sources fail, the system falls back to alternative sources:

```solidity
function getRandomness(uint256 requestId) external view returns (uint256) {
    RandomnessRequest storage request = requests[requestId];
    
    // Try primary source
    if (request.chainlinkFulfilled) {
        return request.chainlinkRandomness;
    }
    
    // Try secondary source
    if (request.drandFulfilled) {
        return uint256(request.drandRandomness);
    }
    
    // Try tertiary source
    if (request.arbitrumFulfilled) {
        return request.arbitrumRandomness;
    }
    
    // Use fallback if all else fails and enough time has passed
    if (block.timestamp >= request.timestamp + FALLBACK_TIMEOUT) {
        return generateFallbackRandomness();
    }
    
    revert("Randomness not yet available");
}
```

## Implementation Details

```mermaid
classDiagram
%% Define interfaces
    class IRandomnessConsumer {
<<interface>>
        +fulfillRandomness(uint256 requestId, uint256 randomness)
    }
    class IRandomnessProvider {
<<interface>>
        +requestRandomness() uint256
        +getRandomness(uint256 requestId) uint256
    }
    %% Define core components
    class RandomnessAggregator {
-mapping(uint256 => RandomnessRequest) requests
        -uint256 requestCounter
        -address chainlinkCoordinator
        -address drandVerifier
        -address arbitrumVRF
        +requestRandomness() uint256
        +fulfillChainlinkRandomness(uint256, uint256[])
        +fulfillDrandRandomness(uint256, bytes, bytes)
        +fulfillArbitrumRandomness(uint256, uint256[])
        +getRandomness(uint256) uint256
        -aggregateRandomness(uint256, bytes32, uint256) uint256
    }
    class ChainlinkConsumer {
-address vrfCoordinator
        -bytes32 keyHash
        -uint64 subscriptionId
        +requestRandomWords() uint256
        +fulfillRandomWords(uint256, uint256[])
    }
    class DrandConsumer {
-address drandVerifier
        -address drandOracle
        +verifyAndUseDrandRandomness(uint256, bytes, bytes) bytes32
    }
    class ArbitrumVRFConsumer {
-address arbVRFCoordinator
        +requestRandomWords() uint256
        +fulfillRandomWords(uint256, uint256[])
    }
    %% Define relationships
    IRandomnessProvider <|.. RandomnessAggregator : implements
    RandomnessAggregator *-- ChainlinkConsumer : uses
    RandomnessAggregator *-- DrandConsumer : uses
    RandomnessAggregator *-- ArbitrumVRFConsumer : uses

    %% Application consumers
    class JackpotSystem {
-IRandomnessProvider randomnessProvider
        +triggerJackpot() uint256
        +fulfillRandomness(uint256, uint256)
    }
    class WinnerSelection {
-IRandomnessProvider randomnessProvider
        +selectWinners(uint256 count) uint256
        +fulfillRandomness(uint256, uint256)
    }
    IRandomnessConsumer <|.. JackpotSystem : implements
    IRandomnessConsumer <|.. WinnerSelection : implements

    %% Apply styling
    classDef interface fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef core fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef source fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef consumer fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    class IRandomnessConsumer interface
    class IRandomnessProvider interface
    class RandomnessAggregator core
    class ChainlinkConsumer source
    class DrandConsumerArbitrumVRFConsumer source
    class JackpotSystem WinnerSelectionconsumer
```

## Randomness Consumers

Various components of the OmniDragon ecosystem consume randomness:

### Jackpot Trigger System

Uses randomness to determine when jackpots should be triggered:

```solidity
function triggerJackpot() external onlyAuthorized returns (uint256) {
    uint256 requestId = randomnessProvider.requestRandomness();
    pendingRequests[requestId] = RequestType.TRIGGER;
    return requestId;
}

function fulfillRandomness(uint256 requestId, uint256 randomness) external override onlyRandomnessProvider {
    if (pendingRequests[requestId] == RequestType.TRIGGER) {
        // Determine if jackpot should trigger based on randomness
        bool shouldTrigger = randomness % 100 < triggerProbability;
        
        if (shouldTrigger) {
            // Trigger jackpot distribution
            jackpotDistributor.initiateDistribution();
        }
        
        delete pendingRequests[requestId];
        emit TriggerProcessed(requestId, randomness, shouldTrigger);
    }
}
```

### Winner Selection

Uses randomness to select jackpot winners from eligible participants:

```solidity
function selectWinners(uint256 count) external onlyAuthorized returns (uint256) {
    uint256 requestId = randomnessProvider.requestRandomness();
    winnerSelectionRequests[requestId] = WinnerRequest({
        count: count,
        processed: false
    });
    return requestId;
}

function fulfillRandomness(uint256 requestId, uint256 randomness) external override onlyRandomnessProvider {
    WinnerRequest storage request = winnerSelectionRequests[requestId];
    if (!request.processed) {
        // Use randomness to select winners
        address[] memory winners = selectWinnersUsingRandomness(randomness, request.count);
        
        // Process winners
        jackpotDistributor.distributeToWinners(winners);
        
        request.processed = true;
        emit WinnersSelected(requestId, winners);
    }
}

function selectWinnersUsingRandomness(uint256 randomness, uint256 count) internal view returns (address[] memory) {
    address[] memory eligibleParticipants = getEligibleParticipants();
    uint256 participantCount = eligibleParticipants.length;
    address[] memory selectedWinners = new address[](count);
    
    // Use randomness as seed
    uint256 seed = randomness;
    
    for (uint256 i = 0; i < count && i < participantCount; i++) {
        // Generate new randomness for each selection
        seed = uint256(keccak256(abi.encodePacked(seed, i)));
        
        // Select random index
        uint256 index = seed % (participantCount - i);
        
        // Get winner at index
        selectedWinners[i] = eligibleParticipants[index];
        
        // Swap selected participant with last unselected one
        eligibleParticipants[index] = eligibleParticipants[participantCount - i - 1];
    }
    
    return selectedWinners;
}
```

## Cross-Chain Randomness

The OmniDragon protocol ensures consistent randomness across multiple chains:

```mermaid
sequenceDiagram
participant Origin as Origin Chain
participant Bridge as LayerZero Bridge
participant Dest as Destination Chain
    Origin->>+Origin: Request randomness
    Origin ->> Origin: Receive randomness
    Origin->>+Bridge: Send randomness to other chains
    Bridge->>+Dest: Deliver randomness
    Dest ->> Dest: Verify and use randomness
    Dest-->>-Bridge: Acknowledge receipt
    Bridge-->>-Origin: Confirm delivery
    Origin-->>-Origin: Update cross-chain state
```

## Key Features

The OmniDragon randomness system provides several important features:

1.**Unpredictability**: Multiple sources ensure truly unpredictable outcomes
2.**Reliability**: Fallback mechanisms prevent system failure
3.**Verifiability**: All randomness can be cryptographically verified
4.**Cross-Chain Consistency**: Same randomness used across all chains
5.**Modularity**: Easy to add new randomness sources or consumers
6.**Security**: Designed to resist manipulation attempts

## Integration Examples

Example of integrating with the randomness system:

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

import "@OmniDragon/interfaces/IRandomnessConsumer.sol";
import "@OmniDragon/interfaces/IRandomnessProvider.sol";

contract RandomnessExample is IRandomnessConsumer {
    IRandomnessProvider public randomnessProvider;
    
    mapping(uint256 => bool) public pendingRequests;
    uint256 public lastRandomValue;
    
    constructor(address _provider) {
        randomnessProvider = IRandomnessProvider(_provider);
    }
    
    function requestRandomNumber() external returns (uint256) {
        uint256 requestId = randomnessProvider.requestRandomness();
        pendingRequests[requestId] = true;
        return requestId;
    }
    
    function fulfillRandomness(uint256 requestId, uint256 randomness) external override {
        require(msg.sender == address(randomnessProvider), "Only provider");
        require(pendingRequests[requestId], "Unknown request");
        
        // Process randomness
        lastRandomValue = randomness;
        delete pendingRequests[requestId];
        
        // Use randomness in application logic
        // ...
    }
}
``` 
