---
sidebar_position: 1
title: Index
description: Detailed explanation of this concept
---

# Randomness System

OmniDragon implements a sophisticated multi-provider randomness system that combines multiple sources of verifiable random functions (VRF) across different blockchains to ensure maximum reliability, security, and manipulation resistance.

## Architecture Overview

The randomness system uses a distributed approach with components across multiple chains, leveraging LayerZero for secure cross-chain communication.

```mermaid
flowchart TD
    subgraph "Sonic Chain"
    A[OmniDragonVRFConsumer] --> B[ChainlinkVRFIntegrator]
    A --> C[drand Integrator]
    A --> D[Other Integrators]
    E[Jackpot Vault] --> A
    F[SwapTriggerOracle] --> A
    G[OmniDragon Token] --> F
    subgraph "LayerZero Network"
    H[Cross-Chain Messaging]
    subgraph "Arbitrum Chain"
    I[ArbitrumVRFRequester] --> J[Chainlink VRF Coordinator]
    end    B <--> H    endH <--> I    end
    end
```

## Key Components

### OmniDragonVRFConsumer

The central hub of the randomness system, aggregating and combining multiple sources of randomness:

- Acts as a multi-source randomness aggregator
- Combines randomness with different weighting factors
- Provides a unified interface for randomness consumers
- Implements fallback mechanisms for reliability

[Learn more about the VRF Consumer](/docs/contracts/randomness/vrf-consumer)

### ChainlinkVRFIntegrator

Connects the OmniDragon ecosystem to Chainlink's VRF service on Arbitrum via LayerZero:

- Receives requests from OmniDragonVRFConsumer
- Forwards requests to Arbitrum via LayerZero
- Receives responses and delivers them back to consumers
- Maintains a local fallback randomness source

[Learn more about the Chainlink Integrator](/docs/contracts/randomness/chainlink)

### ArbitrumVRFRequester

Deployed on Arbitrum to interact with Chainlink's VRF service:

- Receives cross-chain requests from Sonic
- Submits requests to Chainlink VRF
- Forwards randomness results back to Sonic
- Manages Chainlink subscription and configuration

[Learn more about the Arbitrum VRF Requester](/docs/contracts/randomness/arbitrum-vrf)

### VRF Utilities

A library of helper functions for working with random numbers:

- Generating numbers within ranges
- Creating multiple random numbers from a seed
- Selecting random indices
- Shuffling arrays

[Learn more about the VRF Utilities](/docs/contracts/randomness/vrf-utils)

## Cross-Chain Flow

The complete cross-chain randomness flow operates as follows:

```mermaid
sequenceDiagram
participant Consumer as OmniDragon Consumer
participant VRFConsumer as OmniDragonVRFConsumer
participant ChainlinkInt as ChainlinkVRFIntegrator
participant LZ1 as LayerZero (Sonic)
participant LZ2 as LayerZero (Arbitrum)
participant Requester as ArbitrumVRFRequester
participant Chainlink as Chainlink VRF
    Consumer ->> VRFConsumer: requestRandomness()
    VRFConsumer ->> ChainlinkInt: fulfillRandomness(requestId)
    ChainlinkInt ->> ChainlinkInt: Record pending request
    ChainlinkInt ->> LZ1: send(arbitrumChainId, address, payload)

    LZ1 ->> LZ2: Cross-chain message
    LZ2 ->> Requester: lzReceive(srcChainId, srcAddress, payload)
    Requester ->> Requester: Store request mapping
    Requester ->> Chainlink: requestRandomWords()

    Note over Chainlink: Generate verifiable randomness
    Chainlink ->> Requester: fulfillRandomWords(requestId, randomWords)
    Requester ->> LZ2: send(sonicChainId, address, payload)

    LZ2 ->> LZ1: Cross-chain message
    LZ1 ->> ChainlinkInt: lzReceive(srcChainId, srcAddress, payload)
    ChainlinkInt ->> ChainlinkInt: Update latest randomness
    ChainlinkInt ->> VRFConsumer: Send randomness via fulfillRandomness
    VRFConsumer ->> VRFConsumer: Aggregate with other sources
    VRFConsumer ->> Consumer: fulfillRandomness(requestId, randomness)
```

## Security Features

The randomness system implements multiple security measures:

1.**Multi-Source Verification**: Uses multiple independent randomness sources for added security
2.**Cross-Chain Redundancy**: Leverages the security properties of different blockchains
3.**Weighted Aggregation**: Combines randomness with weights to prevent manipulation by any single source
4.**Fallback Mechanisms**: Continues operating even if some randomness sources fail
5.**Request Authentication**: Only authorized consumers can request randomness
6.**Source Validation**: Verifies that cross-chain messages come from trusted contracts
7.**Request Deduplication**: Prevents duplicate processing of randomness requests

## Integration Examples

### Jackpot System

The OmniDragon jackpot system uses the randomness infrastructure to select winners:

```mermaid
flowchart LR
    A[User Swap] --> B[SwapTriggerOracle]
    B --> C[OmniDragonVRFConsumer]
    C --> D[Randomness Aggregation]
    D --> E[Winner Selection]
    E --> F[Jackpot Distribution]
```

### Governance

Random sampling for certain governance decisions:

```mermaid
flowchart LR
    A[Governance Proposal] --> B[Random Committee Selection]
    B --> C[OmniDragonVRFConsumer]
    C --> D[Committee Members]
    D --> E[Proposal Decision]
```

## Using the Randomness System

To integrate with the OmniDragon randomness system, contracts should:

1. Implement the appropriate consumer interface
2. Request authorization from the contract owner
3. Submit randomness requests with unique IDs
4. Implement callback functions to receive randomness

Example basic consumer:

```solidity
// Basic randomness consumer example
contract RandomnessConsumer {
    OmniDragonVRFConsumer public vrfConsumer;
    mapping(uint256 => bool) public pendingRequests;
    uint256 public latestRandomValue;
    
    constructor(address _vrfConsumer) {
        vrfConsumer = OmniDragonVRFConsumer(_vrfConsumer);
    }
    
    function requestRandomness() external returns (uint256) {
        // Generate unique request ID
        uint256 requestId = uint256(keccak256(abi.encode(
            block.timestamp, 
            msg.sender, 
            address(this)
        )));
        
        // Record the request
        pendingRequests[requestId] = true;
        
        // Request randomness
        vrfConsumer.requestRandomness(address(this), requestId);
        
        return requestId;
    }
    
    function fulfillRandomness(
        uint256 _requestId, 
        uint256 _randomValue,
        uint256 _round
    ) external {
        // Verify sender
        require(msg.sender == address(vrfConsumer), "Invalid sender");
        
        // Verify request
        require(pendingRequests[_requestId], "Unknown request");
        
        // Store randomness
        latestRandomValue = _randomValue;
        
        // Clean up
        delete pendingRequests[_requestId];
        
        // Use the randomness
        // ...
    }
}
```

## Gas Considerations

When using the cross-chain randomness system, be aware of the gas costs involved:

1.**Initial Request**: Gas cost on Sonic for initiating the request
2.**Cross-Chain Fee**: LayerZero fee for sending the message to Arbitrum
3.**Chainlink Fee**: LINK token cost for using Chainlink VRF on Arbitrum
4.**Return Message Fee**: LayerZero fee for sending the result back to Sonic
5.**Fulfillment Cost**: Gas cost on Sonic for processing the randomness

The ChainlinkVRFIntegrator includes an `estimateFees()` function to help calculate the cross-chain costs.

## Deployment and Maintenance

Key considerations for operating the randomness system:

1.**Chainlink Subscription**: Maintain a funded Chainlink VRF subscription on Arbitrum
2.**LayerZero Gas**: Ensure sufficient ETH for LayerZero fees on both chains
3.**Oracle Monitoring**: Regularly monitor the health of all randomness sources
4.**Configuration Updates**: Periodically review and update randomness weights and parameters 
