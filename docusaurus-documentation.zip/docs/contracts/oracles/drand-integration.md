---
sidebar_position: 4
title: Drand Integration
description: Detailed explanation of this concept
---

# drand Network Integration

The OmniDragon ecosystem integrates with the drand randomness beacon network to provide verifiable, unpredictable, and unbiasable random values for critical functions like the jackpot system.

## What is drand?

[drand](https://drand.love/) is a distributed randomness beacon operated by the [League of Entropy](https://leagueofentropy.com/), a consortium of research institutions and companies including Protocol Labs, Cloudflare, EPFL, UCL, and others. It provides publicly verifiable random values at regular intervals through a distributed cryptographic protocol.

## Integration Architecture

The drand integration in OmniDragon consists of several components working together:

```mermaid
flowchart TB
subgraph "External drand Networks"
    LoE["League of Entropy<br>(30s beacon)"]
    Quicknet["Quicknet<br>(3s beacon)"]
    EVMnet["EVMnet<br>(EVM-optimized)"]
    subgraph "Off-Chain Components"
    Relay["drand-relay-verifier<br>Service"]
    Monitor["Beacon Monitor"]
    BLSVerifier["BLS Signature Verifier"]
    subgraph "On-Chain Contracts"
    Integrator["DragonVRFIntegrator"]
    OmniConsumer["OmniDragonVRFConsumer"]
    Applications["Jackpot & Applications"]
    LoE -->|"Random Beacon"| Relay
    Quicknet -->|"Random Beacon"| Relay
    EVMnet -->|"Random Beacon"| Relay
    Relay -->|"Verify Signatures"| BLSVerifier
    Relay -->|"Monitor Rounds"| Monitor
    Relay -->|"Update Randomness"| Integrator
    Integrator -->|"Provide Randomness"| OmniConsumer
    OmniConsumer -->|"Aggregated Randomness"| Applications
    classDef highlight fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    end    class Relay primary    endclass Integrator primary    end
    end
```

## Supported drand Networks

The OmniDragon system integrates with multiple drand networks for enhanced reliability:

### League of Entropy Mainnet
-**Chain Hash**: `8990e7a9aaed2ffed73dbd7092123d6f289930540d7651336225dc172e51b2ce`
-**Period**: 30 seconds
-**Public Key**: `868f005eb8e6e4ca0a47c8a77ceaa5309a47978a7c71bc5cce96366b5d7a569937c529eeda66c7293784a9402801af31`

### Quicknet
-**Chain Hash**: `52db9ba70e0cc0f6eaf7803dd07447a1f5477735fd3f661792ba94600c84e971`
-**Period**: 3 seconds
-**Public Key**: `83cf0f2896adee7eb8b5f01fcad3912212c437e0073e911fb90022d3e760183c8c4b450b6a0a6c3ac6a5776a2d1064510d1fec758c921cc22b0e17e63aaf4bcb5ed66304de9cf809bd274ca73bab4af5a6e9c76a4bc09e76eae8991ef5ece45a`

### EVMnet
-**Chain Hash**: `04f1e9062b8a81f848fded9c12306733282b2727ecced50032187751166ec8c3`
-**Period**: 3 seconds
-**Public Key**: `07e1d1d335df83fa98462005690372c643340060d205306a9aa8106b6bd0b3820557ec32c2ad488e4d4f6008f89a346f18492092ccc0d594610de2732c8b808f0095685ae3a85ba243747b1b2f426049010f6b73a0cf1d389351d5aaaa1047f6297d3a4f9749b33eb2d904c9d9ebf17224150ddd7abd7567a9bec6c74480ee0b`
-**Features**: Optimized for EVM chains with BLS-BN254 cryptographic curve support, resulting in lower gas costs for on-chain verification

## drand Relay Verifier

The `drand-relay-verifier` is a critical off-chain service that:

1. Connects to drand networks to receive randomness beacons
2. Verifies beacon signatures using BLS cryptography
3. Relays verified randomness to on-chain contracts
4. Maintains connection reliability across multiple networks

```mermaid
sequenceDiagram
participant drand as drand Network
participant Relay as drand-relay-verifier
participant Contract as DragonVRFIntegrator
    drand ->> Relay: New randomness round
    Relay ->> Relay: Verify BLS signature

    alt Signature Valid
    Relay ->> Contract: updateRandomness(round, value)
    Contract ->> Contract: Store verified randomness
    else Signature Invalid
    Relay ->> Relay: Log error and skip update
```

## BLS Signature Verification

The drand randomness beacons use BLS (Boneh-Lynn-Shacham) signatures, which have the following properties:

1.**Distributed Generation**: Multiple parties contribute to signature creation
2.**Threshold Security**: Requires a threshold of participants to create a valid signature
3.**Public Verifiability**: Anyone can verify the signature with the public key
4.**Uniqueness**: For each round, only one valid signature can exist

The verification process works as follows:

```javascript
// Pseudocode for drand beacon verification
function verifyDrandBeacon(publicKey, round, previousSignature, signature) {
    // Construct the message that was signed
    // In drand, the message is H(prev_sig || round_number)
    const message = hash(previousSignature + round);
    
    // Verify the BLS signature
    return blsVerify(publicKey, message, signature);
}
```

## On-Chain Contracts

### DragonVRFIntegrator

The DragonVRFIntegrator contract serves as the bridge between the off-chain relay and the on-chain randomness consumers:

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract DragonVRFIntegrator {
    // drand network information
    uint256 public latestDrandRound;
    uint256 public latestDrandValue;
    uint256 public lastUpdateTimestamp;
    
    // Only the owner (relay service) can update randomness
    function updateRandomness(uint256 _round, uint256 _value) external onlyOwner {
        require(_round > latestDrandRound, "Round must be newer");
        
        latestDrandRound = _round;
        latestDrandValue = _value;
        lastUpdateTimestamp = block.timestamp;
        
        emit RandomnessUpdated(_round, _value);
    }
    
    // Consumers can retrieve the latest randomness
    function getLatestRandomness() external view returns (uint256, uint256) {
        return (latestDrandValue, latestDrandRound);
    }
}
```

### Direct On-Chain Verification

For applications requiring direct on-chain verification, an extended version of the integrator can be used:

```solidity
// This is a simplified example - actual implementation would use precompiles or optimized libraries
function verifyAndUpdateRandomness(
    uint256 round,
    bytes calldata signature,
    bytes32 previousSignatureHash
) external {
    // Call the BLS verification precompile or library
    bool isValid = drandVerifier.verify(
        drandPublicKey,
        constructMessage(round, previousSignatureHash),
        signature
    );
    
    require(isValid, "Invalid drand signature");
    
    // Calculate randomness value from signature (typically the hash of the signature)
    uint256 randomness = uint256(keccak256(signature));
    
    // Update randomness
    latestDrandRound = round;
    latestDrandValue = randomness;
    lastUpdateTimestamp = block.timestamp;
    
    emit RandomnessUpdated(round, randomness);
}
```

## Relay Service Implementation

The drand relay service is implemented as a Node.js application that connects to drand networks, verifies randomness, and updates on-chain contracts:

```javascript
// Pseudocode for drand relay service
const drandClient = new DrandClient({
    urls: [
        'https://api.drand.sh',
        'https://drand.cloudflare.com'
    ],
    chainHash: '8990e7a9aaed2ffed73dbd7092123d6f289930540d7651336225dc172e51b2ce'
});

// Subscribe to new randomness rounds
drandClient.watchBeacon((beacon) => {
    // Verify the beacon signature
    const isValid = verifyBeacon(beacon);
    
    if (isValid) {
        // Convert the randomness to the format expected by the contract
        const randomness = convertToUint256(beacon.randomness);
        
        // Update the contract with the new randomness
        dragonVRFIntegrator.updateRandomness(beacon.round, randomness);
    }
});
```

## Security Considerations

The drand integration includes several security measures:

1.**Multiple Networks**: Integration with multiple drand networks provides redundancy
2.**Multiple Relays**: Relay services can be operated by different entities
3.**Round Validation**: Contracts only accept newer rounds to prevent replay attacks
4.**Signature Verification**: BLS signatures ensure the randomness comes from drand
5.**Buffer System**: The OmniDragonVRFConsumer's buffer system adds an additional layer of unpredictability

## Benefits for OmniDragon

The drand integration provides several benefits for the OmniDragon ecosystem:

1.**Verifiable Randomness**: All randomness can be cryptographically verified
2.**Public Transparency**: The randomness generation process is transparent and auditable
3.**Manipulation Resistance**: Even protocol operators cannot predict or manipulate the randomness
4.**Regular Schedule**: The predictable timing of randomness generation allows for regular jackpot events
5.**Cross-Chain Consistency**: The same randomness source can be used across multiple blockchains

## Technical Deep Dive: drand Protocol

At a technical level, drand works as follows:

1.**Setup Phase**: 
   - Participants generate BLS key pairs
   - Through a distributed key generation protocol, a group public key is created
   - Private key shares are distributed among participants

2.**Beacon Generation**:
   - For round 0, a signature on a specified message is created
   - For round n, a signature on H(prev_sig || round_number) is created
   - A threshold t of the n participants must contribute to create a valid signature

3.**Verification**:
   - Anyone can verify the signature using the drand group public key
   - The deterministic message construction ensures only one valid signature exists per round

This creates a chain of linked, unpredictable, and verifiable random values. 
