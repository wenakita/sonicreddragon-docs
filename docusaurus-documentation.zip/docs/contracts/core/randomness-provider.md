---
title: Randomness Provider
sidebar_position: 1
description: Detailed explanation of this concept
---
# OmniDragon Randomness Provider

The**OmniDragonRandomnessProvider**is the single source of truth for all randomness in the OmniDragon ecosystem. It manages multiple VRF sources, provides fallback mechanisms, and serves randomness to any authorized consumer with cost-efficient bucket systems.

## Overview

The Randomness Provider serves as the central hub for:
-**Multiple VRF Sources**: Chainlink VRF 2.5 via LayerZero, Drand networks
-**Cost-Efficient Systems**: Bucket system for high-frequency requests
-**Fallback Mechanisms**: Automatic switching between VRF sources
-**Enhanced Security**: Aggregated randomness from multiple sources
-**Universal Service**: Serves any authorized consumer (jackpot, games, etc.)

## Contract Architecture

<div className="mermaid-container">
  <div className="mermaid-controls">
    <button className="mermaid-btn">Zoom In</button>
    <button className="mermaid-btn">Zoom Out</button>
    <button className="mermaid-btn">Reset View</button>
    <button className="mermaid-btn">Replay</button>
  </div>

```mermaid
%%{init: {
    'theme': 'base',
    'themeVariables': {
    'primaryColor': '#f8fafc',
    'primaryTextColor': '#334155',
    'primaryBorderColor': '#64748b',
    'lineColor': '#64748b',
    'secondaryColor': '#f1f5f9',
    'tertiaryColor': '#e2e8f0'
    }
    }
    }
    %%
    graph TB
subgraph "Core Controller"
    RP[Randomness Provider<br/>Central Orchestrator]
    AC[Access Control<br/>Authorization Manager]
    EM[Emergency Manager<br/>Circuit Breaker]
    subgraph "VRF Sources"
    CI[Chainlink Integrator<br/>LayerZero Bridge]
    DI[Drand Integrator<br/>Beacon Aggregator]
    FB[Fallback Manager<br/>Source Switching]
    subgraph "Storage Systems"
    BS[Bucket System<br/>Cost Optimization]
    PS[Pool System<br/>Pre-generated Numbers]
    CS[Cache System<br/>Recent Results]
    subgraph "External Sources"
    VRF[Chainlink VRF 2.5<br/>Arbitrum Network]
    LE[League of Entropy<br/>Main Beacon]
    QN[Quicknet<br/>Fast Rounds]
    EN[EVMnet<br/>EVM Optimized]
    RP --> AC
    RP --> EM
    RP --> CI
    RP --> DI
    RP --> FB
    RP --> BS
    RP --> PS
    RP --> CS
    CI --> VRF
    DI --> LE
    DI --> QN
    DI --> EN
    FB --> CI
    FB --> DI
    classDef default fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef controller fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef vrf fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef storage fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef external fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    class RP controller
    class ACEM controller
    class CI vrf
    class DIFB vrf
    class BS storage
    class PSCS storage
    class VRF external
    class LEQN external
    class EN external
    end
    end
    end
    end```
</div>

## VRF Sources Hierarchy

<div className="mermaid-container">
  <div className="mermaid-controls">
    <button className="mermaid-btn">Zoom In</button>
    <button className="mermaid-btn">Zoom Out</button>
    <button className="mermaid-btn">Reset View</button>
    <button className="mermaid-btn">Replay</button>
  </div>

```mermaid
%%{init: {
    'theme': 'base',
    'themeVariables': {
    'primaryColor': '#f8fafc',
    'primaryTextColor': '#334155',
    'primaryBorderColor': '#64748b',
    'lineColor': '#64748b',
    'secondaryColor': '#f1f5f9',
    'tertiaryColor': '#e2e8f0'
    }
    }
    }
    %%

    graph TD
    A[Randomness Request] --> B{Source Selection}
    B --> C[Primary: Chainlink VRF 2.5]
    B --> D[Secondary: Drand Aggregated]
    B --> E[Fallback: Bucket System]

    C --> F[LayerZero Bridge to Arbitrum]
    F --> G[VRF Coordinator]
    G --> H[Cryptographic Proof]
    H --> I[LayerZero Return]
    I --> J[Sonic Verification]

    D --> K[League of Entropy]
    D --> L[Quicknet]
    D --> M[EVMnet]
    K --> N[Beacon Aggregation]
    L --> N
    M --> N
    N --> O[Signature Verification]

    E --> P[Pre-generated Pool]
    P --> Q[Bucket Selection]
    Q --> R[Deterministic Draw]

    J --> S[Final Randomness]
    O --> S
    R --> S

    S --> T[Consumer Callback]

    classDef default fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef primary fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef secondary fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef fallback fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    class C primary
    class FG primary
    class H primary
    class I primary
    class J primary
    class D secondary
    class KL secondary
    class M secondary
    class N secondary
    class O secondary
    class E fallback
    class PQ fallback
    class R fallback
```
</div>

## Bucket System Flowchart

<div className="mermaid-container">
  <div className="mermaid-controls">
    <button className="mermaid-btn">Zoom In</button>
    <button className="mermaid-btn">Zoom Out</button>
    <button className="mermaid-btn">Reset View</button>
    <button className="mermaid-btn">Replay</button>
  </div>

```mermaid
%%{init: {
    'theme': 'base',
    'themeVariables': {
    'primaryColor': '#f8fafc',
    'primaryTextColor': '#334155',
    'primaryBorderColor': '#64748b',
    'lineColor': '#64748b',
    'secondaryColor': '#f1f5f9',
    'tertiaryColor': '#e2e8f0'
    }
    }
    }
    %%

    flowchart TD
    A[VRF Seed Request] --> B{Bucket Available?}
    B -->|Yes| C[Select Bucket]
    B -->|No| D[Generate New Bucket]
    C --> E[Calculate Index]
    E --> F[Extract Number]
    F --> G[Mark as Used]
    G --> H[Return Random Number]
    D --> I[Request VRF Seed]
    I --> J[Receive Seed]
    J --> K[Generate 1000 Numbers]
    K --> L[Store in Bucket]
    L --> M[Set Expiry: 24h]
    M --> C
    H --> N[Update Usage Stats]
    N --> O{Bucket Empty?}
    O -->|Yes| P[Mark for Cleanup]
    O -->|No| Q[Continue Operations]
    P --> R[Schedule Regeneration]
    Q --> S[Monitor Usage]
    R --> T[Background Process]
    S --> T
    T --> U[Optimize Performance]
    classDef default fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef process fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef storage fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef optimization fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    class A process
    class E process
    class F process
    class I process
    class J process
    class C storage
    class KL storage
    class M storage
    class N optimization
    class OP optimization
    class R optimization
    class T optimization
    class U optimization
```
</div>

## Randomness Pool System

<div className="mermaid-container">
  <div className="mermaid-controls">
    <button className="mermaid-btn">Zoom In</button>
    <button className="mermaid-btn">Zoom Out</button>
    <button className="mermaid-btn">Reset View</button>
    <button className="mermaid-btn">Replay</button>
  </div>

```mermaid
%%{init: {
    'theme': 'base',
    'themeVariables': {
    'primaryColor': '#f8fafc',
    'primaryTextColor': '#334155',
    'primaryBorderColor': '#64748b',
    'lineColor': '#64748b',
    'secondaryColor': '#f1f5f9',
    'tertiaryColor': '#e2e8f0'
    }
    }
    }
    %%
    graph LR
subgraph "Pool Management"
    PM[Pool Manager]
    RF[Refresh Timer: 30min]
    QM[Quality Monitor]
    subgraph "Active Pool"
    AP[Current Pool<br/>500 Numbers]
    UI[Usage Index]
    TS[Timestamp]
    subgraph "Standby Pool"
    SP[Standby Pool<br/>500 Numbers]
    PS[Pre-generated]
    RD[Ready State]
    subgraph "Generation Process"
    VG[VRF Generator]
    DG[Drand Generator]
    AG[Aggregator]
    PM --> RF
    PM --> QM
    PM --> AP
    PM --> SP
    RF --> VG
    VG --> AG
    DG --> AG
    AG --> SP
    AP --> UI
    AP --> TS
    SP --> PS
    SP --> RD
    QM --> VG
    QM --> DG
    classDef default fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef management fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef pool fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef generation fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    class PM management
    class RFQM management
    class AP pool
    class UITS pool
    class SP pool
    class PS pool
    class RD pool
    class VG generation
    class DGAG generation
    end
    end
    end
    end```
</div>

## Drand Network Aggregation

<div className="mermaid-container">
  <div className="mermaid-controls">
    <button className="mermaid-btn">Zoom In</button>
    <button className="mermaid-btn">Zoom Out</button>
    <button className="mermaid-btn">Reset View</button>
    <button className="mermaid-btn">Replay</button>
  </div>

```mermaid
%%{init: {
    'theme': 'base',
    'themeVariables': {
    'primaryColor': '#f8fafc',
    'primaryTextColor': '#334155',
    'primaryBorderColor': '#64748b',
    'lineColor': '#64748b',
    'secondaryColor': '#f1f5f9',
    'tertiaryColor': '#e2e8f0'
    }
    }
    }
    %%
    graph TB
subgraph "Global Networks"
    LE[League of Entropy<br/>Main Network<br/>30s rounds]
    QN[Quicknet<br/>Fast Network<br/>3s rounds]
    EN[EVMnet<br/>EVM Optimized<br/>12s rounds]
    subgraph "Aggregation Layer"
    DA[Drand Aggregator]
    SV[Signature Verifier]
    TS[Timestamp Sync]
    RH[Round Handler]
    subgraph "Quality Control"
    QC[Quality Checker]
    FD[Freshness Detector]
    CD[Corruption Detector]
    FB[Fallback Trigger]
    subgraph "Output Processing"
    RA[Random Aggregator]
    EN2[Entropy Mixer]
    FO[Final Output]
    LE --> DA
    QN --> DA
    EN --> DA
    DA --> SV
    DA --> TS
    DA --> RH
    SV --> QC
    TS --> FD
    RH --> CD
    QC --> RA
    FD --> RA
    CD --> FB
    FB --> RA
    RA --> EN2
    EN2 --> FO
    classDef default fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef network fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef aggregation fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef quality fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef output fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    class LE network
    class QNEN network
    class DA aggregation
    class SVTS aggregation
    class RH aggregation
    class QC quality
    class FDCD quality
    class FB quality
    end    class RA output    endclass EN2FO output    end
    end
    end```
</div>

## Request Lifecycle

<div className="mermaid-container">
  <div className="mermaid-controls">
    <button className="mermaid-btn">Zoom In</button>
    <button className="mermaid-btn">Zoom Out</button>
    <button className="mermaid-btn">Reset View</button>
    <button className="mermaid-btn">Replay</button>
  </div>

```mermaid
%%{init: {
    'theme': 'base',
    'themeVariables': {
    'primaryColor': '#f8fafc',
    'primaryTextColor': '#334155',
    'primaryBorderColor': '#64748b',
    'lineColor': '#64748b',
    'secondaryColor': '#f1f5f9',
    'tertiaryColor': '#e2e8f0'
    }
    }
    }
    %%

    sequenceDiagram
participant C as Consumer
participant RP as Randomness Provider
participant CI as Chainlink Integrator
participant DI as Drand Integrator
participant BS as Bucket System
    C ->> RP: requestRandomness(seed)
    RP ->> RP: validateRequest()
    RP ->> RP: selectSource()

    alt Primary: Chainlink VRF
    RP ->> CI: requestVRF(seed)
    CI ->> CI: bridgeToArbitrum()
        CI -->> RP: vrfPending()
    CI ->> CI: receiveVRF()
    CI ->> RP: fulfillRandomness(proof)
    else Secondary: Drand
    RP ->> DI: requestDrand()
    DI ->> DI: aggregateBeacons()
    DI ->> RP: fulfillRandomness(signature)
    else Fallback: Bucket
    RP ->> BS: getBucketNumber()
    BS ->> BS: selectFromPool()
    BS ->> RP: returnNumber()
    RP ->> RP: verifyRandomness()
    RP ->> RP: storeResult()
    RP ->> C: fulfillRandomness(result)
    C ->> C: processResult()

    classDef default fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
```
</div>

## Cost Model Visualization

<div className="mermaid-container">
  <div className="mermaid-controls">
    <button className="mermaid-btn">Zoom In</button>
    <button className="mermaid-btn">Zoom Out</button>
    <button className="mermaid-btn">Reset View</button>
    <button className="mermaid-btn">Replay</button>
  </div>

```mermaid
%%{init: {
    'theme': 'base',
    'themeVariables': {
    'primaryColor': '#f8fafc',
    'primaryTextColor': '#334155',
    'primaryBorderColor': '#64748b',
    'lineColor': '#64748b',
    'secondaryColor': '#f1f5f9',
    'tertiaryColor': '#e2e8f0'
    }
    }
    }
    %%

    graph TD
    A[Protocol Operations] --> B{Cost Model}
    B --> C[Protocol Funded]
    B --> D[Consumer Funded]

    C --> E[Bucket Generation<br/>$50 per 1000 numbers]
    C --> F[Pool Maintenance<br/>$30 per refresh]
    C --> G[Drand Aggregation<br/>$5 per request]

    D --> H[Premium VRF<br/>$100 per request]
    D --> I[Instant Delivery<br/>$25 surcharge]
    D --> J[Custom Parameters<br/>Variable cost]

    E --> K[Cost Efficiency<br/>$0.05 per number]
    F --> L[Reliability<br/>99.9% uptime]
    G --> M[Speed<br/>&lt1s response]

    H --> N[Maximum Security<br/>Cryptographic proof]
    I --> O[Immediate Response<br/>No waiting]
    J --> P[Flexibility<br/>Custom requirements]

    classDef default fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef protocol fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef consumer fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    classDef benefit fill:#4a80d1,stroke:#4a80d1,stroke-width:2px,color:#ffffff
    class C protocol
    class EF protocol
    class G protocol
    class D consumer
    class HI consumer
    class J consumer
    class K benefit
    class LM benefit
    class N benefit
    class O benefit
    class P benefit
```
</div>

## Performance Metrics

<div className="mermaid-container">
  <div className="mermaid-controls">
    <button className="mermaid-btn">Zoom In</button>
    <button className="mermaid-btn">Zoom Out</button>
    <button className="mermaid-btn">Reset View</button>
    <button className="mermaid-btn">Replay</button>
  </div>

```mermaid
%%{init: {
    'theme': 'base',
    'themeVariables': {
    'primaryColor': '#f8fafc',
    'primaryTextColor': '#334155',
    'primaryBorderColor': '#64748b',
    'lineColor': '#64748b',
    'xyChart': {
      'backgroundColor': '#ffffff',
      'titleColor': '#1e293b',
      'xAxisLabelColor': '#475569',
      'yAxisLabelColor': '#475569',
      'xAxisTitleColor': '#334155',
      'yAxisTitleColor': '#334155',
      'plotColorPalette': '#64748b,#94a3b8,#cbd5e1,#e2e8f0'
    }
    }
    }
    }
    %%

    xychart-beta
    title "VRF Method Comparison"
    x-axis "Metrics" ["Cost", "Latency", "Security", "Throughput"]
    y-axis "Score (1-10)" 0 --> 10
    bar "Chainlink VRF" [3, 6, 10, 4]
    bar "Drand Aggregated" [8, 9, 8, 7]
    bar "Bucket System" [10, 10, 6, 10]
    bar "Pool System" [9, 9, 7, 9]
```
</div>

## Key Features

### Multiple VRF Sources
-**Chainlink VRF 2.5**: Premium cryptographic randomness via LayerZero
-**Drand Networks**: Distributed beacon aggregation from multiple sources
-**Bucket System**: Cost-efficient pre-generated randomness pools
-**Automatic Fallback**: Seamless switching between sources

### Cost Optimization
-**Bucket System**: Generate 1000 numbers from single VRF seed
-**Pool Management**: Pre-generated randomness for instant delivery
-**Protocol Funding**: Most operations funded by protocol treasury
-**Flexible Pricing**: Consumer-funded premium options available

### Security Features
-**Multi-Source Verification**: Cross-validation between VRF sources
-**Cryptographic Proofs**: Verifiable randomness with mathematical guarantees
-**Access Control**: Role-based permissions and emergency controls
-**Audit Trail**: Complete logging of all randomness generation

### Performance Characteristics

| Method | Cost | Latency | Security | Throughput | Use Case |
|--------|------|---------|----------|------------|----------|
|**Chainlink VRF**| High | ~30s | Maximum | Low | Critical operations |
|**Drand Aggregated**| Low | &lt;1s | High | General purpose |
|**Bucket Draw**| Very Low | &lt;1s | Medium | High-frequency |
|**Pool System**| Low | Instant | Medium | High | Real-time applications |

## Integration Examples

### Basic Randomness Request
```solidity
// Request randomness from the provider
uint256 requestId = randomnessProvider.requestRandomness(
    keccak256(abi.encodePacked(block.timestamp, msg.sender))
);
```

### Consumer Implementation
```solidity
contract LotteryConsumer is IRandomnessConsumer {
    function fulfillRandomness(uint256 requestId, uint256 randomness) 
        external override {
        // Process the randomness
        uint256 winner = randomness % totalParticipants;
        selectWinner(winner);
    }
}
```

### Advanced Configuration
```solidity
// Configure VRF source preferences
randomnessProvider.setSourcePreference(
    VRFSource.CHAINLINK_PRIMARY,
    VRFSource.DRAND_SECONDARY,
    VRFSource.BUCKET_FALLBACK
);
```

## Security Considerations

### Access Control
-**Role-based permissions**for all critical functions
-**Timelock protection**for parameter changes
-**Emergency pause**capability for security incidents
-**Multi-signature**requirements for sensitive operations

### Randomness Quality
-**Entropy validation**for all sources
-**Freshness checks**to prevent replay attacks
-**Signature verification**for Drand beacons
-**Proof validation**for Chainlink VRF responses

### Economic Security
-**Protocol funding**reduces consumer costs
-**Fallback mechanisms**ensure service continuity
-**Cost monitoring**prevents economic attacks
-**Rate limiting**protects against spam

The OmniDragon Randomness Provider represents a comprehensive solution for secure, cost-effective, and reliable randomness generation in the DeFi ecosystem, supporting everything from high-frequency gaming applications to critical jackpot operations.



 
